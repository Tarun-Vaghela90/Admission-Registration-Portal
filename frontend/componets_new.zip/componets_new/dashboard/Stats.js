import React from 'react';

function Stats() {
  return (
    <div className="stats">
      <div className="stat">
        <h3>Total Application</h3>
        <p>100</p>
      </div>
      {/* ... other stats ... */}
    </div>
  );
}

export default Stats;